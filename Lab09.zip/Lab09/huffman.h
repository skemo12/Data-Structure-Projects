#ifndef __HUFFMAN_H__
#define __HUFFMAN_H__

#include <string.h>

typedef struct {
    unsigned char value;
    int left, right;
} HuffmanNode;

#define Item int

// Including below so `Item` is defined.
#include "heap.h"

void computeFreqs(char *text, int size, int freqs[256]) {

    for (int i = 0; i < 256; i++)
    {
        freqs[i] = 0;
    }
    
    for (int i = 0; i < size; i++)
    {
        
        int code = text[i];
        freqs[code]++;
        //printf("%d %d || ",code, freqs[code]);
    }
    
}

HuffmanNode *makeTree(int freqs[256], int *size) {
    //HuffmanNode *nodes = (HuffmanNode *) calloc(*size, sizeof(HuffmanNode));

    //int currentSize = 0;
    //
    for (int i = 0; i < 256; i++)
    {
        if (freqs[i] != 0)
        {
            *(size++);
        }
        
    }
    
    APriQueue minHeap = makeQueue(*size);
    for (int i = 0; i < 256; i++)
    {
        if (freqs[i] != 0)
        {
            ItemType x;
            x.prior = freqs[i];
            x.content = i;
            insert(minHeap, x);
        }
        
    }
    
    while (minHeap->size >= 2)
    {
        printf("%d\n",minHeap->size);
        ItemType last1 = removeMin(minHeap);
        ItemType last2 = removeMin(minHeap);

        ItemType newNode;
        newNode.prior = last1.prior + last2.prior;
        newNode.content = last1.content + last2.content;

        insert(minHeap, newNode);
    }
    
    HuffmanNode *root = minHeap->elem;
    
    return root;
}

void makeCodes(int index, HuffmanNode *nodes, char **codes, char *code) {
}

char *compress(char *text, int textSize, HuffmanNode *nodes, int numNodes) {
}

char *decompress(char *text, int textSize, HuffmanNode *nodes, int numNodes) {
}

#endif
